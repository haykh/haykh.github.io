#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ArduinoOTA.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266WebServer.h>
#include <FS.h>

ESP8266WebServer server(80);
const char * SSID = "<SSID>";
const char * PASS = "<PASS>";

#include "Initialize.h"
#include "Myserver.h"

void setup() {
  Serial.begin(74880);
  initializeWifi();
  initializeOTA();
  SPIFFS.begin();
  myClientServer.initialize();
  myClientServer.serialPrintln(String("Connected to ") + WiFi.localIP().toString());
}

unsigned long timer = 0L;

void loop() {
  ArduinoOTA.handle();
  myClientServer.handle();
  if (millis() - timer > 2000L) {
    myClientServer.serialPrintln(String(random(100)));
    timer = millis();
  }
}
