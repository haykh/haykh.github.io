#ifndef MYSERVER_H
#define MYSERVER_H

File fsUploadFile;
String getContentType(String filename);
bool handleFileRead(String path);
void handleFileUpload();
void handleSerialMonitor();

struct ClientServer {
  ClientServer();
  void initialize();
  void handle();
  String getFilesystem();
  void serialPrint(String message);
  void serialPrintln(String message);

  String serial_message;

} myClientServer;

ClientServer::ClientServer() {
  serial_message = "";
}

void ClientServer::initialize() {
  server.on("/upload", HTTP_GET, []() {
    if (!handleFileRead("/uploader.html"))
      server.send(404, "text/plain", "404: Not Found");
  });
  server.on("/upload", HTTP_POST,
    [](){ server.send(200); },
    handleFileUpload
  );
  server.onNotFound([]() {
    if (!handleFileRead(server.uri()))
      server.send(404, "text/plain", "404: Not Found");
  });
  server.on("/getSerialMonitor", handleSerialMonitor);
  server.begin();
}

void ClientServer::serialPrint(String message) {
  serial_message += message;
  if (serial_message.length() > 10000L) { // reset if message is longer than 10000 symbols
    serial_message = message;
  }
}
void ClientServer::serialPrintln(String message) { // print with a line break
  serial_message += "\n" + message;
  if (serial_message.length() > 10000L) {
    serial_message = message;
  }
}

void ClientServer::handle() {
  server.handleClient();
}

String ClientServer::getFilesystem() {
  Dir dir = SPIFFS.openDir("/");
  String str = "";
  while (dir.next()) {
      str += dir.fileName();
      str += " / ";
      str += dir.fileSize();
      str += "\r\n";
  }
  return str;
}

String getContentType(String filename) { // convert the file extension to the MIME type
  if (filename.endsWith(".html")) return "text/html";
  else if (filename.endsWith(".css")) return "text/css";
  else if (filename.endsWith(".js")) return "application/javascript";
  else if (filename.endsWith(".ico")) return "image/x-icon";
  else if (filename.endsWith(".gz")) return "application/x-gzip";
  return "text/plain";
}

bool handleFileRead(String path) { // send the right file to the client (if it exists)
  Serial.println("handleFileRead: " + path);
  if (path.endsWith("/")) path += "index.html";          // If a folder is requested, send the index file
  String contentType = getContentType(path);             // Get the MIME type
  String pathWithGz = path + ".gz";
  if (SPIFFS.exists(pathWithGz) || SPIFFS.exists(path)) { // If the file exists, either as a compressed archive, or normal
    if (SPIFFS.exists(pathWithGz))                         // If there's a compressed version available
      path += ".gz";                                         // Use the compressed verion
    File file = SPIFFS.open(path, "r");                    // Open the file
    size_t sent = server.streamFile(file, contentType);    // Send it to the client
    file.close();                                          // Close the file again
    Serial.println(String("\tSent file: ") + path);
    return true;
  }
  Serial.println(String("\tFile Not Found: ") + path);   // If the file doesn't exist, return false
  return false;
}

void handleFileUpload(){ // upload a new file to the SPIFFS
  HTTPUpload& upload = server.upload();
  if(upload.status == UPLOAD_FILE_START){
    String filename = upload.filename;
    if(!filename.startsWith("/")) filename = "/"+filename;
    Serial.print("handleFileUpload Name: "); Serial.println(filename);
    fsUploadFile = SPIFFS.open(filename, "w");            // Open the file for writing in SPIFFS (create if it doesn't exist)
    filename = String();
  } else if(upload.status == UPLOAD_FILE_WRITE){
    if(fsUploadFile)
      fsUploadFile.write(upload.buf, upload.currentSize); // Write the received bytes to the file
  } else if(upload.status == UPLOAD_FILE_END){
    if(fsUploadFile) {                                    // If the file was successfully created
      fsUploadFile.close();                               // Close the file again
      Serial.print("handleFileUpload Size: "); Serial.println(upload.totalSize);
      server.sendHeader("Location","/success.html");      // Redirect the client to the success page
      server.send(303);
    } else {
      server.send(500, "text/plain", "500: couldn't create file");
    }
  }
}

void handleSerialMonitor() {
  server.send(200, "text/plane", String(myClientServer.serial_message));
}

#endif
